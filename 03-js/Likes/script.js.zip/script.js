function increaseLikes () {
    var numbLikes = document.querySelector(".numbLikes");
    var numCount = Number(numbLikes.innerText);
    numCount++
    numbLikes.innerText = numCount
}

function increaseLikes2 () {
    var numbLikes2 = document.querySelector(".numbLikes2");
    var numCount = Number(numbLikes2.innerText);
    numCount++
    numbLikes2.innerText = numCount
}

function increaseLikes3 () {
    var numbLikes3 = document.querySelector(".numbLikes3");
    var numCount = Number(numbLikes3.innerText);
    numCount++
    numbLikes3.innerText = numCount
}